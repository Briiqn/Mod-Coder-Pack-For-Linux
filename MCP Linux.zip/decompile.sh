#!/bin/bash
python2 runtime/decompile.py "$@"
